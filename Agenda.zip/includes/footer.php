<?php ?>
</main>
<footer class="border-t mt-8 py-6 text-center text-xs text-gray-500">
  © <?= date('Y') ?> Rijschool Agenda
</footer>
<script src="/assets/theme.js"></script>
</body>
</html>
