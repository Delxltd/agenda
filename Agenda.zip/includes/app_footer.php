<?php
$__layout = $GLOBALS['__APP_LAYOUT'] ?? 'app';
if ($__layout === 'auth'): ?>
    </main>
  </div><!-- /.auth-shell -->
</body>
</html>
<?php else: ?>
  </div><!-- /.container -->
</body>
</html>
<?php endif; ?>
