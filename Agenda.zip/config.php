<?php
// === CONFIG ===
// Vul hier je database gegevens in:
define('DB_HOST', 'localhost');
define('DB_NAME', 'u142407p436219_new');
define('DB_USER', 'u142407p436219_new');
define('DB_PASS', 'QgFJvdysa7D6HrveSyC2');

// Basis URL (laat meestal op '/')
define('APP_URL', '/');

// Tijdzone
date_default_timezone_set('Europe/Amsterdam');
