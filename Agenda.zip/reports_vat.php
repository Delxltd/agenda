<?php
require_once __DIR__ . '/includes/helpers.php'; require_login();
$page_title = 'BTW & Omzet'; $nav_active = 'reports';
require __DIR__ . '/includes/app_header.php';
?>
<div class="card"><h2>BTW & Omzet</h2><p>Overzicht + export komt hier.</p></div>
<?php require __DIR__ . '/includes/app_footer.php'; ?>
