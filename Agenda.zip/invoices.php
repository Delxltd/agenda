<?php
require_once __DIR__ . '/includes/helpers.php'; require_login();
$page_title = 'Facturen'; $nav_active = 'invoices';
require __DIR__ . '/includes/app_header.php';
?>
<div class="card"><h2>Facturen</h2><p>Factuurmodule kan hier geïntegreerd worden.</p></div>
<?php require __DIR__ . '/includes/app_footer.php'; ?>
